import java.util.Scanner;

public class Main {
    public static int toplama(int a, int b, int c) {
        return (a + b + c);
    }

    public static int toplama(int a, int b) {
        return (a + b);
    }

    public static int carpma(int a, int b, int c) {
        return (a * b * c);
    }

    public static int carpma(int a, int b) {
        return (a * b);
    }

    public static int cikarma(int a, int b) {
        return (a - b);
    }

    public static double bolme(int a, int b) {
        return ((double) a / b);
    }

    public static void main(String[] args) {
        int a, b, c;
        String islemler = "1. Toplama İşlemi\n2. Çıkarma İşlemi\n3. Çarpma İşlemi\n4. Bölme İşlemi\nÇıkış için q basınız.";
        Scanner scanner = new Scanner(System.in);
        while (true) {
            System.out.println(islemler);
            System.out.print("İşlem Seçiniz: ");
            String islem = scanner.nextLine();
            if (islem.equals("q")) {
                System.out.println("Programdan çıkılıyor...");
                break;
            }
            else if (islem.equals("1")) {
                System.out.println("Kaç sayı girmek istiyorsunuz? (2 veya 3?)");
                int kacSayi = scanner.nextInt();
                if (kacSayi==2) {
                    System.out.print("1. Sayıyı giriniz: ");
                    a = scanner.nextInt();
                    System.out.print("2. Sayıyı giriniz: ");
                    b = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Girilen sayıların toplamı = "+toplama(a, b));
                }
                else if (kacSayi==3) {
                    System.out.print("1. Sayıyı giriniz: ");
                    a = scanner.nextInt();
                    System.out.print("2. Sayıyı giriniz: ");
                    b = scanner.nextInt();
                    System.out.print("3. Sayıyı giriniz: ");
                    c = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Girilen sayıların toplamı = "+toplama(a, b, c));
                }
                else {
                    scanner.nextLine();
                    System.out.println("Bunun için uygun metod bulunmuyor!");
                }


            }
            else if (islem.equals("2")) {
                System.out.print("1. Sayıyı giriniz: ");
                a = scanner.nextInt();
                System.out.print("2. Sayıyı giriniz: ");
                b = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Girilen sayıların farkı = "+cikarma(a,b));

            }
            else if (islem.equals("3")) {
                System.out.println("Kaç sayı girmek istiyorsunuz? (2 veya 3?)");
                int kacSayi = scanner.nextInt();
                if (kacSayi==2) {
                    System.out.print("1. Sayıyı giriniz: ");
                    a = scanner.nextInt();
                    System.out.print("2. Sayıyı giriniz: ");
                    b = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Girilen sayıların çarpımı = "+carpma(a,b));
                }
                else if (kacSayi==3) {
                    System.out.print("1. Sayıyı giriniz: ");
                    a = scanner.nextInt();
                    System.out.print("2. Sayıyı giriniz: ");
                    b = scanner.nextInt();
                    System.out.print("3. Sayıyı giriniz: ");
                    c = scanner.nextInt();
                    scanner.nextLine();
                    System.out.println("Girilen sayıların çarpımı = "+carpma(a, b, c));
                }
                else {
                    scanner.nextLine();
                    System.out.println("Bunun için uygun metod bulunmuyor!");
                }

            }
            else if (islem.equals("4")) {
                System.out.print("1. Sayıyı giriniz: ");
                a = scanner.nextInt();
                System.out.print("2. Sayıyı giriniz: ");
                b = scanner.nextInt();
                scanner.nextLine();
                System.out.println("Girilen sayıların bölümü = "+bolme(a,b));

            }
            else {
                System.out.println("Geçerli işlem seçmediniz!");
            }
        }


    }
}