import java.util.Scanner;

public class Login {
    public boolean girisYap(Hesap hesap){
        Scanner scanner=new Scanner(System.in);
        String kAdi;
        String sifre;
        System.out.println("Kullanıcı Adınız: ");
        kAdi=scanner.nextLine();
        System.out.println("Şifrenizi Giriniz: ");
        sifre=scanner.nextLine();
        if(hesap.getkAdi().equals(kAdi)&&hesap.getSifre().equals(sifre)){
            return true;
        }
        else {
            return false;
        }
    }
}
