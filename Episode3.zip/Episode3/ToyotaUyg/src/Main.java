import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("Toyota Fabrikasına Hoşgeldiniz...");
        System.out.println("Çıkış için q'ya basınız.");
        Scanner scanner=new Scanner(System.in);
        while (true){
            System.out.println("Hangi aracı üretmek istiyorsunuz? ");
            String islem=scanner.nextLine();
            if (islem.equals("q")){
                System.out.println("Programdan çıkılıyor...");
                break;
            }
            else {
                ToyotaFabrikasi fabrika=new ToyotaFabrikasi();
                Toyota toyota=fabrika.toyotaUret(islem);
                if (toyota==null){
                    System.out.println("Lütfen geçerli bir model ismi giriniz...");
                }
                else {
                    toyota.bilgileriGoster();
                    toyota.testSurusu();
                    toyota.topSpeed();
                }
            }
        }
    }
}