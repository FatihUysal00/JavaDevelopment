import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Bankamıza hoşgeldiniz. Faiz Oranı %6");
        System.out.println("Yatırmak istediğiniz para miktarı: ");
        int anapara = scanner.nextInt();
        System.out.println("Paranızı kaç yıl vadeli yatırmak istiyorsunuz? : ");
        int vade = scanner.nextInt();
        double toplampara = anapara;
        double faizoran = 0.06;
        for (int i = 1; i <= vade; i++) {
            toplampara = (toplampara * faizoran) + toplampara;
            System.out.println(i + " .Yılın sonunda toplam para miktarınız: " + (int)toplampara);
        }

    }
}