public class Arac {
    private String aracPlaka;
    private String aracModel;
    private int aracYil;
    private int aracKm;
    private String aracRenk;
    private double aracFiyat;

    public Arac(){

    }
    public Arac(String aracPlaka,String aracModel, int aracYil, int aracKm, String aracRenk, double aracFiyat) {
        this.aracPlaka=aracPlaka;
        this.aracModel = aracModel;
        this.aracYil = aracYil;
        this.aracKm = aracKm;
        this.aracRenk = aracRenk;
        this.aracFiyat = aracFiyat;
    }

    public String getAracPlaka() {
        return aracPlaka;
    }

    public void setAracPlaka(String aracPlaka) {
        this.aracPlaka = aracPlaka;
    }

    public String getAracModel() {
        return aracModel;
    }

    public void setAracModel(String aracModel) {
        this.aracModel = aracModel;
    }

    public int getAracYil() {
        return aracYil;
    }

    public void setAracYil(int aracYil) {
        this.aracYil = aracYil;
    }

    public int getAracKm() {
        return aracKm;
    }

    public void setAracKm(int aracKm) {
        this.aracKm = aracKm;
    }

    public String getAracRenk() {
        return aracRenk;
    }

    public void setAracRenk(String aracRenk) {
        this.aracRenk = aracRenk;
    }

    public double getAracFiyat() {
        return aracFiyat;
    }

    public void setAracFiyat(double aracFiyat) {
        this.aracFiyat = aracFiyat;
    }
    public void fiyatGuncelle(String plaka,double fiyat){
        if (aracPlaka.equals(plaka)){
            aracFiyat=fiyat;
            System.out.println("Aracın yeni fiyatı: "+aracFiyat+" TL");
        }
        else{
            System.out.println("Geçerli plaka girmediniz!!");
        }
    }

}
