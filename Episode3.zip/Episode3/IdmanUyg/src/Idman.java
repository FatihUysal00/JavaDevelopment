public class Idman {
    private int barfiksSayisi;
    private int sinavSayisi;
    private int mekikSayisi;
    private int squatSayisi;

    public Idman(int barfiksSayisi, int sinavSayisi, int mekikSayisi, int squatSayisi) {
        this.barfiksSayisi = barfiksSayisi;
        this.sinavSayisi = sinavSayisi;
        this.mekikSayisi = mekikSayisi;
        this.squatSayisi = squatSayisi;
    }

    public int getBarfiksSayisi() {
        return barfiksSayisi;
    }

    public void setBarfiksSayisi(int barfiksSayisi) {
        this.barfiksSayisi = barfiksSayisi;
    }

    public int getSinavSayisi() {
        return sinavSayisi;
    }

    public void setSinavSayisi(int sinavSayisi) {
        this.sinavSayisi = sinavSayisi;
    }

    public int getMekikSayisi() {
        return mekikSayisi;
    }

    public void setMekikSayisi(int mekikSayisi) {
        this.mekikSayisi = mekikSayisi;
    }

    public int getSquatSayisi() {
        return squatSayisi;
    }

    public void setSquatSayisi(int squatSayisi) {
        this.squatSayisi = squatSayisi;
    }
    public void hareketYap(String hareketTuru, int sayi){
        if (hareketTuru.equals("Barfiks")){
            barfiksYap(sayi);
        }
        else if (hareketTuru.equals("Şınav")) {
            sinavYap(sayi);
        }
        else if (hareketTuru.equals("Mekik")) {
            mekikYap(sayi);
        }
        else if (hareketTuru.equals("Squat")) {
            squatYap(sayi);
        }
        else{
            System.out.println("Geçersiz Hareket!!!");
        }
    }

    public void barfiksYap(int sayi){
        if (barfiksSayisi==0){
            System.out.println("Yapacak barfiks kalmadı!");
        }
        if (barfiksSayisi-sayi<0){
            System.out.println("Hedeflediğin barfiks sayısını geçtin, Tebrikler!");
            barfiksSayisi=0;
            System.out.println("Kalan Barfiks sayısı: "+barfiksSayisi);
        }
        else {
            barfiksSayisi-=sayi;
            System.out.println("Kalan Barfiks sayısı: "+barfiksSayisi);
        }
    }

    public void sinavYap(int sayi){
        if (sinavSayisi==0){
            System.out.println("Yapacak şınav kalmadı!");
        }
        if (sinavSayisi-sayi<0){
            System.out.println("Hedeflediğin şınav sayısını geçtin, Tebrikler!");
            sinavSayisi=0;
            System.out.println("Kalan Şınav sayısı: "+sinavSayisi);
        }
        else{
            sinavSayisi-=sayi;
            System.out.println("Kalan Şınav sayısı: "+sinavSayisi);
        }
    }

    public void mekikYap(int sayi){
        if (mekikSayisi==0){
            System.out.println("Yapacak mekik kalmadı!");
        }
        if (mekikSayisi-sayi<0){
            System.out.println("Hedeflediğin mekik sayısını geçtin, Tebrikler!");
            mekikSayisi=0;
            System.out.println("Kalan mekik sayısı: "+mekikSayisi);
        }
        else{
            mekikSayisi-=sayi;
            System.out.println("Kalan mekik sayısı: "+mekikSayisi);
        }
    }
    public void squatYap(int sayi){
        if (squatSayisi==0){
            System.out.println("Yapacak squat kalmadı!");
        }
        if (squatSayisi-sayi<0){
            System.out.println("Hedeflediğin squat sayısını geçtin, Tebrikler!");
            squatSayisi=0;
            System.out.println("Kalan squat sayısı: "+squatSayisi);
        }
        else {
            squatSayisi-=sayi;
            System.out.println("Kalan Squat sayısı: "+squatSayisi);
        }
    }
    public boolean idmanBittiMi(){
        return (barfiksSayisi==0)&&(sinavSayisi==0)&&(mekikSayisi == 0)&&(squatSayisi == 0);
    }
}
