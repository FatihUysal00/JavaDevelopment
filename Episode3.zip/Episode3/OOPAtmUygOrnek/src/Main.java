public class Main {
    public static void main(String[] args) {
        ATM atm=new ATM();
        Hesap hesap=new Hesap("Fatih UYSAL","1234",10000);
        atm.calis(hesap);
        System.out.println("Çıkış yapılıyor....");
    }
}