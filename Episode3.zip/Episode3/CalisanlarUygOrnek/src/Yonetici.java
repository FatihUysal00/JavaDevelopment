public class Yonetici extends Calisan{
    private int sorumluKisiSayisi;

    public Yonetici(String ad, String soyad, int id, int sorumluKisiSayisi) {
        super(ad, soyad, id);
        this.sorumluKisiSayisi = sorumluKisiSayisi;
    }

    public int getSorumluKisiSayisi() {
        return sorumluKisiSayisi;
    }

    public void setSorumluKisiSayisi(int sorumluKisiSayisi) {
        this.sorumluKisiSayisi = sorumluKisiSayisi;
    }

    @Override
    public void bilgileriGoster() {
        super.bilgileriGoster();
        System.out.println("Sorumlu Olduğu Kişi Sayısı: "+sorumluKisiSayisi);
    }
    public void zamYap(int zamMiktar){
        System.out.println(getAd()+" adlı yönetici çalışanlara "+zamMiktar+" TL kadar zam yaptı..");
    }
}
