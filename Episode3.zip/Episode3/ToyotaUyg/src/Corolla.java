public class Corolla extends Toyota{
    private String kasaTipi;
    private boolean sunroof=false;

    public Corolla(String model, double motorGucu, String donanim, String kasaTipi, boolean sunroof) {
        super(model, motorGucu, donanim);
        this.kasaTipi = kasaTipi;
        this.sunroof = sunroof;
    }
    @Override
    public void testSurusu() {
        super.testSurusu();
    }

    @Override
    public void bilgileriGoster() {
        super.bilgileriGoster();
        System.out.println("Kasa Tipi = "+kasaTipi);
        if (sunroof==true){
            System.out.println("Sunroof var.");
        }
        else {
            System.out.println("Sunroof yok.");
        }
    }

    public void sunroofAc(){
        if (sunroof==true){
            System.out.println("Sunroof açılıyor...");
        }
        else {
            System.out.println("Bu araçta sunroof bulunmamaktadır.");
        }
    }

}
