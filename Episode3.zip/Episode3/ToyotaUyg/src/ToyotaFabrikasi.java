public class ToyotaFabrikasi {
    public Toyota toyotaUret(String modelIsmi){
        if (modelIsmi.equals("Corolla")){
            return new Corolla("Corolla",1.6,"Flame X","Sedan",true);
        } else if (modelIsmi.equals("Auris")) {
            return new Auris("Auris",1.5,"Vision","Hatchback");
        } else if (modelIsmi.equals("Yaris")) {
            return new Yaris("Yaris",1.2,"Dream","Hatchback");
        }else {
            return null;
        }
    }
}
