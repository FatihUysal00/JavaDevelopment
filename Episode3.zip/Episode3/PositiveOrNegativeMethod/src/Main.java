import java.util.Scanner;

public class Main {
    public static boolean positiveOrNegative(int a){
        if(a<0){
            return false;
        }
        else{
            return true;
        }
    }
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("Sayı giriniz: ");
        int a= scanner.nextInt();
        if (positiveOrNegative(a)){
            System.out.println("Sayı pozitiftir.");
        }
        else{
            System.out.println("Sayı negatiftir.");
        }
    }
}