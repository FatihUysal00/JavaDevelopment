public class Hesap {
    private String kullaniciAdi;
    private String parola;
    private double bakiye;

    private Double kalanBakiye;

    public Hesap() {

    }

    public Hesap(String kullaniciAdi, String parola, double bakiye) {
        this.kullaniciAdi = kullaniciAdi;
        this.parola = parola;
        this.bakiye = bakiye;
    }

    public Double getKalanBakiye() {
        return kalanBakiye;
    }

    public void setKalanBakiye(Double kalanBakiye) {
        this.kalanBakiye = kalanBakiye;
    }

    public String getKullaniciAdi() {
        return kullaniciAdi;
    }

    public void setKullaniciAdi(String kullaniciAdi) {
        this.kullaniciAdi = kullaniciAdi;
    }

    public String getParola() {
        return parola;
    }

    public void setParola(String parola) {
        this.parola = parola;
    }

    public double getBakiye() {
        return bakiye;
    }

    public void setBakiye(double bakiye) {
        this.bakiye = bakiye;
    }

    public void  paraYatir(int tutar){
        this.bakiye+=tutar;
        System.out.println("Yeni bakiyeniz: "+bakiye);
    }

    public void paraCek(int tutar){
        if((bakiye-tutar)<0){
            System.out.println("Yeterli bakiyeniz yok...");
        }
        else{
            bakiye-=tutar;
            System.out.println("Yeni bakiyeniz: "+bakiye);
        }
    }

    @Override
    public String toString() {
        return "Hesap {" +
                "kullaniciAdi='" + kullaniciAdi + '\'' +
                ", parola='" + parola + '\'' +
                ", bakiye=" + bakiye +
                ", kalanBakiye=" + kalanBakiye +
                '}';
    }
}
