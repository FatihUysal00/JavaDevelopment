public class Yaris extends Toyota{
    private String kasaTipi;

    public Yaris(String model, double motorGucu, String donanim, String kasaTipi) {
        super(model, motorGucu, donanim);
        this.kasaTipi = kasaTipi;
    }

    @Override
    public void testSurusu() {
        super.testSurusu();
    }

    @Override
    public void bilgileriGoster() {
        super.bilgileriGoster();
        System.out.println("Kasa Tipi = "+kasaTipi);
    }
}
