public class Hesap {
    private String kAdi;
    private String sifre;
    private double bakiye;

    public Hesap(String kAdi, String sifre, double bakiye) {
        this.kAdi = kAdi;
        this.sifre = sifre;
        this.bakiye = bakiye;
    }

    public String getkAdi() {
        return kAdi;
    }

    public void setkAdi(String kAdi) {
        this.kAdi = kAdi;
    }

    public String getSifre() {
        return sifre;
    }

    public void setSifre(String sifre) {
        this.sifre = sifre;
    }

    public double getBakiye() {
        return bakiye;
    }

    public void setBakiye(double bakiye) {
        this.bakiye = bakiye;
    }

    public void paraYatir(int tutar){
        bakiye+=tutar;
        System.out.println("Güncel Bakiye : "+bakiye);

    }
    public void paraCek(int tutar){
        if ((bakiye-tutar)<-2000){
            System.out.println("Çekmek istediğiniz tutar esnek hesap bakiyesini aşıyor, bu limiti çekemezsiniz.");
        }
        else {
            bakiye-=tutar;
            System.out.println("Güncel Bakiye : "+bakiye);
        }

    }
}
