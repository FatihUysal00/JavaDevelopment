import java.util.Scanner;

public class Main {
    public static int minDeger(int a, int b) {
        if (a <= b) {
            return a;
        }
        else {
            return b;
        }

    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("1. Sayıyı giriniz: ");
        int a = scanner.nextInt();
        System.out.print("2. Sayıyı giriniz: ");
        int b = scanner.nextInt();
        System.out.println("Girmiş olduğunuz sayılardan küçük olan = "+minDeger(a,b)+" 'dır.");

    }
}