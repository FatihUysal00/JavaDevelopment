public class Main {
    public static void main(String[] args) {
        SatilanArac satilanArac=new SatilanArac("34ZY9324","TOYOTA COROLLA",2001,216000,"BEYAZ",305000,"SATILIK");
        satilanArac.fiyatGuncelle("34ZY9324",350000);
        satilanArac.aracGetir("34ZY9324");

        satilanArac.aracAl("34FTH10","PEUGEOT 106",1997,120000,"KIRMIZI",250000,"SATILDI");

        satilanArac.aracGetir("34FTH10");

        satilanArac.fiyatGuncelle("34FTH10",315000);

        satilanArac.aracGetir("34FTH10");
        satilanArac.fiyatGuncelle("34FTH10",50000);
        satilanArac.aracGetir("34FTH10");

    }
}