import java.util.LinkedList;
import java.util.ListIterator;
import java.util.Scanner;

public class Main {
    public static void islemleriGoster(){
        String islem="0 - İşlemleri Görüntüle\n1 - Bir sonraki şehre git\n2 - Bir önceki şehre git\n3 - Uygulamadan Çık";
        System.out.println(islem);
    }
    public static void sehirleriTurla(LinkedList<String> sehirler){
        ListIterator<String> iterator=sehirler.listIterator();
        Scanner scanner=new Scanner(System.in);
        islemleriGoster();
        if (!iterator.hasNext()){
            System.out.println("Herhangi bir şehir bulunmuyor!!");
        }
        boolean cikis=true;
        boolean ileri=true;
        int islem;
        while (cikis){
            System.out.println("İşlem seçiniz:");
            islem=scanner.nextInt();
            switch (islem){
                case 0:
                    islemleriGoster();
                    break;
                case 1:
                    if (!ileri){
                        if (iterator.hasNext()){
                            iterator.next();
                        }
                        ileri=true;
                    }
                    if (iterator.hasNext()){
                        System.out.println("Şehre gidiliyor.. "+iterator.next());
                    }
                    else {
                        System.out.println("Gidilecek şehir kalmadı..");
                        ileri=true;
                    }
                    break;
                case 2:
                    if (ileri){
                        if (iterator.hasPrevious()){
                            iterator.previous();
                        }
                        ileri=false;
                    }
                    if (iterator.hasPrevious()){
                        System.out.println("Şehre gidiliyor... "+iterator.previous());
                    }else {
                        System.out.println("Şehir turu başladı..");
                    }
                    break;
                case 3:
                    cikis=false;
                    System.out.println("Uygulamadan çıkılıyor..");
                    break;
            }

        }
    }
    public static void main(String[] args) {
        LinkedList<String > sehirler=new LinkedList<String>();
        sehirler.add("İstanbul");
        sehirler.add("Ankara");
        sehirler.add("Afyon");
        sehirler.add("Denizli");
        sehirleriTurla(sehirler);

    }
}