import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner=new Scanner(System.in);
        System.out.println("İdman programına hoşgeldiniz...");
        String idmanlar="Geçerli Hareketler...\nBarfiks\nŞınav\nMekik\nSquat";
        System.out.println(idmanlar);
        System.out.println("Bir idman oluşturun...");
        System.out.println("Barfiks Sayısı: ");
        int barfiksSayisi=scanner.nextInt();
        System.out.println("Şınav Sayısı: ");
        int sinavSayisi=scanner.nextInt();
        System.out.println("Mekik Sayısı: ");
        int mekikSayisi=scanner.nextInt();
        System.out.println("Squat Sayısı: ");
        int squatSayisi=scanner.nextInt();
        scanner.nextLine();
        Idman idman=new Idman(barfiksSayisi,sinavSayisi,mekikSayisi,squatSayisi);
        System.out.println("İdmanınız başlıyor...");
        while(idman.idmanBittiMi()==false){
            System.out.println("Hareket Türü(Barfiks,Şınav,Mekik,Squat): ");
            String tur=scanner.nextLine();
            System.out.println("Bu hareketten kaç tane yapacaksınız? : ");
            int sayi= scanner.nextInt();
            scanner.nextLine();
            idman.hareketYap(tur,sayi);
        }
        System.out.println("İdmanını başarıyla bitirdin...");
    }
}