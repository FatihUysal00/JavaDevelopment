import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        String kadi0 = "Fatih";
        String parola0 = "Uysal";
        int giris_hakki = 3;
        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("Kullanıcı Adınızı Girin: ");
            String kadi = scanner.nextLine();
            System.out.println("Şifre Giriniz: ");
            String parola = scanner.nextLine();
            if (kadi.equals(kadi0) && parola.equals(parola0)) {
                System.out.println("Hoşgeldiniz, "+kadi);
                break;

            }
            else if(kadi.equals(kadi0) && !parola.equals(parola0)) {
                System.out.println("Parolanız yanlış...");
                giris_hakki-=1;
                System.out.println("Giriş Hakkı: "+giris_hakki);
            }
            else if(!kadi.equals(kadi0) && parola.equals(parola0)) {
                System.out.println("Kullanıcı adınız yanlış...");
                giris_hakki-=1;
                System.out.println("Giriş Hakkı: "+giris_hakki);
            }
            else {
                System.out.println("Kullanıcı adınız ve parolanız yanlış...");
                giris_hakki-=1;
                System.out.println("Giriş Hakkı: "+giris_hakki);
            }
            if(giris_hakki==0){
                System.out.println("Giriş hakkınız kalmadı!!");
                break;
            }

        }


/*
        do {

            System.out.println("Kullanıcı Adınızı Girin: ");
            String kadi = scanner.nextLine();
            System.out.println("Şifre Giriniz: ");
            String parola = scanner.nextLine();
            if (kadi0.equals(kadi) && parola0.equals(parola)) {
                System.out.println("Hoşgeldiniz...");
                break;

            } else {
                giris_hakki--;
                System.out.println("Yanlış Kullanıcı Adı veya Şifre Girdiniz!!! Kalan Deneme Hakkınız: " + giris_hakki);
                if (giris_hakki == 0) {
                    System.out.println("Giriş hakkınız kalmadı.");
                    break;
                }

            }
        } while (giris_hakki <= 3);

*/



/*
        while (giris_hakki <= 3) {

            System.out.println("Kullanıcı Adınızı Girin: ");
            String kadi = scanner.nextLine();
            System.out.println("Şifre Giriniz: ");
            String parola = scanner.nextLine();


            if (kadi0.equals(kadi) && parola0.equals(parola)) {
                System.out.println("Hoşgeldiniz...");
                break;
            } else {
                giris_hakki--;
                System.out.println("Yanlış Kullanıcı Adı veya Şifre Girdiniz!!! Kalan Deneme Hakkınız: " + giris_hakki);
                if (giris_hakki == 0) {
                    System.out.println("Giriş hakkınız kalmadı.");
                    break;
                }
            }

        }

 */
    }
}
