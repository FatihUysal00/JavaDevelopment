import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        System.out.println("************************************");
        System.out.println("Çalışanlar Uygulamasına Hoşgeldiniz!");
        System.out.println("************************************");
        String menu="1. Yazılımcı İşlemleri\n2. Yönetici İşlemleri\nÇıkış için q basın.";
        System.out.println(menu);
        Scanner scanner=new Scanner(System.in);
        while (true){
            System.out.println("İşlem seçiniz: ");
            String islem=scanner.nextLine();
            if (islem.equals("q")){
                System.out.println("Programdan çıkılıyor...");
                break;
            } else if (islem.equals("1")) {
                Yazilimci yazilimci=new Yazilimci("Fatih","UYSAL",579,"Java,C++");
                String yazilimciMenu="1. Bilgileri Göster\n2. Format At\nÇıkış için q basın.";
                System.out.println(yazilimciMenu);
                while (true){
                    System.out.println("Yazılımcı menüsü için işlem seçiniz: ");
                    String yazilimciIslem=scanner.nextLine();
                    if (yazilimciIslem.equals("q")){
                        System.out.println("Yazılımcı menüsünden çıkılıyor...");
                        break;
                    } else if (yazilimciIslem.equals("1")) {
                        yazilimci.bilgileriGoster();
                    } else if (yazilimciIslem.equals("2")) {
                        System.out.println("İşletim Sistemi giriniz: ");
                        String isletimSistemi=scanner.nextLine();
                        yazilimci.formatAt(isletimSistemi);
                    }else {
                        System.out.println("Geçersiz yazılımcı işlemi seçtiniz..");
                    }
                }
            } else if (islem.equals("2")) {
                Yonetici yonetici=new Yonetici("Ahmet","KARA",45,25);
                String yoneticiMenu="1. Bilgileri Göster\n2. Zam Yap\nÇıkış için q basın.";
                System.out.println(yoneticiMenu);
                while (true){
                    System.out.println("Yönetici menüsü için işlem seçiniz: ");
                    String yoneticiIslem=scanner.nextLine();
                    if (yoneticiIslem.equals("q")){
                        System.out.println("Yönetici menüsünden çıkılıyor...");
                        break;
                    } else if (yoneticiIslem.equals("1")) {
                        yonetici.bilgileriGoster();
                    } else if (yoneticiIslem.equals("2")) {
                        System.out.println("Zam miktarı giriniz: ");
                        int zamMiktari= scanner.nextInt();
                        scanner.nextLine();
                        yonetici.zamYap(zamMiktari);
                    }else {
                        System.out.println("Geçersiz yönetici işlemi seçtiniz..");
                    }
                }
            }else {
                System.out.println("Geçersiz İşlem seçtiniz...");
            }
        }

    }
}