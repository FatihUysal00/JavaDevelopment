public class Toyota {
    private String marka="TOYOTA";
    private String model;
    private double motorGucu;
    private String donanim="Vision";

    public Toyota(String model, double motorGucu, String donanim) {
        this.model = model;
        this.motorGucu = motorGucu;
        if (donanim.equals("Dream")|| donanim.equals("Vision") || donanim.equals("Flame X")){
            this.donanim = donanim;//Encapsulation Durumu
        }
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getMotorGucu() {
        return motorGucu;
    }

    public void setMotorGucu(double motorGucu) {
        this.motorGucu = motorGucu;
    }

    public String getDonanim() {
        return donanim;
    }

    public void setDonanim(String donanim) {
        this.donanim = donanim;
    }
    public void testSurusu(){
        System.out.println(marka+" "+model+" test sürüşüne çıkıyor..");
    }
    public void bilgileriGoster(){
        System.out.println("Marka = "+marka);
        System.out.println("Model = "+model);
        System.out.println("Motor Gücü = "+motorGucu);
        System.out.println("Donanım Paketi = "+donanim);
    }
    public void topSpeed(){
        this.motorGucu=motorGucu;
        if (motorGucu==1.6){
            System.out.println("TOP SPEED: 220KM/H");
        }else if (motorGucu<1.6){
            System.out.println("TOP SPEED: 180KM/H");
        }
    }
}
