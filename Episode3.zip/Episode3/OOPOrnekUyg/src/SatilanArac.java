public class SatilanArac extends Arac{
    private String satildiMi;
    public SatilanArac(String aracPlaka,String aracModel, int aracYil, int aracKm, String aracRenk, double aracFiyat,String satildiMi) {
        super(aracPlaka,aracModel,aracYil,aracKm,aracRenk,aracFiyat);
        this.satildiMi = satildiMi;
    }
    public void aracAl(String plaka, String model, int yil,int km,String renk, double fiyat,String satildiMi){
        setAracPlaka(plaka);
        setAracModel(model);
        setAracYil(yil);
        setAracKm(km);
        setAracRenk(renk);
        setAracFiyat(fiyat);
        this.satildiMi=satildiMi;

    }
    public void aracGetir(String plaka){
        if (getAracPlaka().equals(plaka)){
            System.out.println("Plakasını girdiğiniz araç bilgileri: ");
            System.out.println(getAracPlaka()+"\n"+getAracModel()+"\n"+getAracYil()+"\n"+getAracRenk()+"\n"+getAracKm()+" KM\n"+getAracFiyat()+" TL"+"\n"+this.satildiMi);
        }
        else {
            System.out.println("Girdiğiniz plakaya ait veri bulunamadı!!");
        }

    }
}
