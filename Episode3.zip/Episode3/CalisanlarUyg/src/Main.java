import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Çalışanlar Programına Hoşgeldiniz....");
        String islemler = "İşlemler...\n1. Yazılımcı İşlemleri\n2. Yönetici İşlemleri\nÇıkış için q basın.";
        System.out.println("*******************************************");
        System.out.println(islemler);
        System.out.println("*******************************************");
        while (true) {
            System.out.println("İşlemi Seçiniz: ");
            String islem = scanner.nextLine();
            if (islem.equals("q")) {
                System.out.println("Programdan çıkılıyor...");
                break;
            } else if (islem.equals("1")) {
                Yazilimci yazilimci = new Yazilimci("Fatih", "UYSAL", 5, "C#,JAVA");
                String yazilimciIslem = "1. Format At\n2. Bilgileri Göster\nÇıkış için q basın.";
                System.out.println(yazilimciIslem);
                while (true) {
                    System.out.println("İşlemi seçiniz: ");
                    String y_islem = scanner.nextLine();
                    if (y_islem.equals("q")) {
                        System.out.println("Yazılımcı İşlemlerinden Çıkılıyor..");
                        break;
                    } else if (y_islem.equals("1")) {
                        System.out.println("İşletim Sistemi: ");
                        String isletimSistemi = scanner.nextLine();
                        yazilimci.formatAt(isletimSistemi);
                    } else if (y_islem.equals("2")) {
                        yazilimci.bilgileriGoster();
                    } else {
                        System.out.println("Geçersiz yazılımcı işlemi...");
                    }

                }

            } else if (islem.equals("2")) {
                Yonetici yonetici = new Yonetici("Serhat", "SAY", 123, 10);
                String yoneticiIslem = "Yönetici İşlemleri\n1. Zam Yap\n2. Bilgileri Göster\nÇıkış için q basın.";
                System.out.println(yoneticiIslem);
                while (true) {
                    System.out.println("İşlem Seçiniz: ");
                    String y_islem = scanner.nextLine();
                    if (y_islem.equals("q")) {
                        System.out.println("Yönetici İşlemlerinden Çıkılıyor...");
                        break;
                    } else if (y_islem.equals("1")) {
                        System.out.println("Yöneticinin ne kadar zam yapmasını istiyorsunuz?: ");
                        int zamMiktari = scanner.nextInt();
                        scanner.nextLine();
                        yonetici.zamYap(zamMiktari);
                    } else if (y_islem.equals("2")) {
                        yonetici.bilgileriGoster();
                    } else {
                        System.out.println("Geçersiz yönetici işlemi...");
                    }
                }

            } else {
                System.out.println("Geçersiz işlem!");
            }
        }

    }
}