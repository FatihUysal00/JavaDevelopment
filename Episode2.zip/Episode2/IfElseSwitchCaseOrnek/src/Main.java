import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Girilen sayının çift veya tek olduğunu bulan prog.

//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Sayı giriniz: ");
//        int sayi=scanner.nextInt();
//        if (sayi%2==0)
//        {
//            System.out.println("Sayı çifttir. Sayı: "+ sayi);
//        }
//        else{
//            System.out.println("Sayı tektir. Sayı: "+ sayi);
//        }

        //1-7 arasında girilen değere göre gün karşılığını veren programı yazınız.

//        Scanner scanner=new Scanner(System.in);
//        System.out.println("1 ile 7 arasında bir sayı giriniz: ");
//        int secim=scanner.nextInt();
//        switch (secim){
//            case 1:
//                System.out.println("Pazartesi");
//                break;
//            case 2:
//                System.out.println("Salı");
//                break;
//            case 3:
//                System.out.println("Çarşamba");
//                break;
//            case 4:
//                System.out.println("Perşembe");
//                break;
//            case 5:
//                System.out.println("Cuma");
//                break;
//            case 6:
//                System.out.println("Cumartesi");
//                break;
//            case 7:
//                System.out.println("Pazar");
//                break;
//            default:
//                System.out.println("Uygun bir değer girmediniz!!!");
//                break;
//        }


        //kullanıcının girmiş olduğu karaktere göre hangi kitap türünü seçtini bulan programı yapınız.
        // B-Bilgisayar M-Matematik T-Tarih İ-İngilizce

//        Scanner scanner=new Scanner(System.in);
//        while(true){
//            System.out.println("Kitap Türleri\nB-Bilgisayar\nM-Matematik\nT-Tarih\nİ-İngilizce");
//            System.out.println("Kitap türü seçiniz: ");
//            char secim=scanner.next().charAt(0);
//            switch (secim){
//            case 'B':
//                System.out.println("Kitap türü 'Bilgisayar' seçildi.");
//                break;
//            case 'M':
//                System.out.println("Kitap türü 'Matematik' seçildi.");
//                break;
//            case 'T':
//                System.out.println("Kitap türü 'Tarih' seçildi.");
//                break;
//            case 'İ':
//                System.out.println("Kitap türü 'İngilizce' seçildi.");
//                break;
//            default:
//                System.out.println("Uygun seçim yapmadınız!!!!");
//                continue;
//
//            }
//            break;
//        }

        //Alışveriş tutarına göre aşağıda verilen tablodaki indirim miktarını uygulayan program
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Alışveriş tutarı giriniz: ");
//        int tutar=scanner.nextInt();
//        double indirim=0;
//        if (tutar<1000) {
//            indirim=tutar*0.05;
//            tutar-=indirim;
//            System.out.println("İndirim miktarı: "+indirim);
//            System.out.println("Ödenecek tutar: "+tutar);
//        }
//        else if (tutar>1000 && tutar<10000){
//            indirim=tutar*0.08;
//            tutar-=indirim;
//            System.out.println("İndirim miktarı: "+indirim);
//            System.out.println("Ödenecek tutar: "+tutar);
//        }
//        else{
//            indirim=tutar*0.085;
//            tutar-=indirim;
//            System.out.println("İndirim miktarı: "+indirim);
//            System.out.println("Ödenecek tutar: "+tutar);
//        }

        //Hava durumuna göre giyim öneren program
//        Scanner scanner=new Scanner(System.in);
//        System.out.println("Hava durumu girin: ");
//        String durum=scanner.nextLine();
//        switch (durum){
//            case "Güneşli":
//                System.out.println("Kısa kollu giyebilirsiniz..");
//                break;
//            case "Yağmurlu":
//                System.out.println("Mont giyebilirsiniz..");
//                break;
//            case "Karlı":
//                System.out.println("Mont ve bot giyebilirsiniz..");
//                break;
//            default:
//                System.out.println("Geçersiz durum girdiniz!");
//                break;
//        }

        //4 İşlem switch case
        Scanner scan = new Scanner(System.in);
        while (true){
            System.out.println("Hesap Makinesi uygulamasına hoşgeldiniz!");
            System.out.println("Devam etmek için 'ileri' yazınız..\nProgramdan çıkmak için 'q' yazınız...");
            String secim = scan.nextLine();
            if (secim.equals("ileri")) {
                while (true) {
                    System.out.println("1. Sayıyı giriniz: ");
                    int sayi1 = scan.nextInt();
                    System.out.println("2. Sayıyı giriniz: ");
                    int sayi2 = scan.nextInt();
                    scan.nextLine();
                    System.out.println("Seçebileceğiniz İşlemler\n+\n-\n*\n/");
                    System.out.println("İşlem seçiniz: ");
                    char islem = scan.next().charAt(0);
                    switch (islem) {
                        case '+':
                            System.out.println(sayi1 + " + " + sayi2 + " = " + (sayi1 + sayi2));
                            break;
                        case '-':
                            System.out.println(sayi1 + " - " + sayi2 + " = " + (sayi1 - sayi2));
                            break;
                        case '*':
                            System.out.println(sayi1 + " * " + sayi2 + " = " + (sayi1 * sayi2));
                            break;
                        case '/':
                            System.out.println(sayi1 + " / " + sayi2 + " = " + ((double) sayi1 / sayi2));
                            break;
                        default:
                            System.out.println("Yanlış işlem seçtiniz!!!");
                            break;
                    }

                    Scanner scan1 = new Scanner(System.in);
                    System.out.println("Devam etmek istiyor musunuz?");
                    String yesorno=scan1.nextLine();
                    if (yesorno.equals("Hayır")){
                        break;
                    }
                }
            }
            else if (secim.equals("q")) {
                System.out.println("Programdan çıkılıyor...");
                break;
            }
            else{
                System.out.println("Yanlış işlem yapıldı!!");
            }
            break;
        }

    }
}