import java.util.ArrayList;

public class Sarkicilar {
    private ArrayList<String> sarkiciListesi=new ArrayList<String>();
    public void sarkicilariBastir(){
        System.out.println("Şarkıcı Listesinde "+sarkiciListesi.size()+" kadar şarkıcı var.");
        for (int i = 0; i < sarkiciListesi.size(); i++) {
            System.out.println((i+1)+". Şarkıcı "+sarkiciListesi.get(i));
        }
    }
    public void sarkiciEkle(String isim){
        sarkiciListesi.add(isim);
        System.out.println("Şarkıcı Listesi Güncellendi.");
    }
    public void sarkiciGuncelle(String yeni_isim,int pozisyon){
        sarkiciListesi.set(pozisyon,yeni_isim);
        System.out.println("Şarkıcı Listesi Güncellendi.");
    }
    public void sarkiciSil(int pozisyon){
        String isim=sarkiciListesi.get(pozisyon);
        sarkiciListesi.remove(pozisyon);
        System.out.println(isim+" isimli şarkıcı listeden silindi..");
    }
    public void sarkiciAra(String sarkici_ismi){
        int pozisyon=sarkiciListesi.indexOf(sarkici_ismi);
        if (pozisyon>=0){
            System.out.println("Şarkıcı Bulundu..");
            System.out.println(sarkici_ismi+" isimli şarkıcı "+(pozisyon+1)+". pozisyonda");
        }
        else {
            System.out.println("Şarkıcı bulunamadı..");
        }
    }
}
