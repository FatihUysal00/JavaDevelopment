public class Main {
    public static void main(String[] args) {

        Hesap hesap2 = new Hesap();
        hesap2.setKullaniciAdi("Eray Gürsoy");
        hesap2.setParola("123654");

        System.out.println("Hesap2..: " + hesap2.getKullaniciAdi() + " " + hesap2.getParola() + " " + hesap2.getBakiye() + " " + hesap2.getKalanBakiye());

        System.out.println("-------------------------------------------------");

        System.out.println(hesap2);

        System.out.println("Programdan çıkılıyor...");
    }
}
