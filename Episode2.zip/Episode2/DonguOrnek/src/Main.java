import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        //Kullanıcının Girdiği Aralıktaki Tek Sayıları Yazdıran Java Prog.
       /* Scanner scanner=new Scanner(System.in);
        System.out.println("Başlangıç sayısı giriniz: ");
        int altsayi=scanner.nextInt();
        System.out.println("Son sayıyı giriniz: ");
        int sonsayi=scanner.nextInt();
        for (int i = altsayi; i <=sonsayi ; i++) {
            if (i%2==1){
                System.out.println(i);
            }

        }*/


        //Klavyeden Girilen 10 sayının toplamını yazdıran prog.

        /*Scanner scanner=new Scanner(System.in);
        int toplam=0;
        for (int i = 1; i <= 10; i++) {
            System.out.print(i+". sayıyı giriniz: ");
            int sayi=scanner.nextInt();
            toplam+=sayi;
        }
        System.out.println("Girilen 10 adet sayının toplamı: "+toplam);*/

        //Kullanıcının girdiği aralıktaki sayıların çift olanını ekrana yazdıran prog. While ile

        /*Scanner scanner=new Scanner(System.in);
        System.out.println("Alt sayıyı giriniz: ");
        int altsayi=scanner.nextInt();
        System.out.println("Üst sayıyı giriniz: ");
        int ustsayi=scanner.nextInt();

        while(altsayi<=ustsayi){
            if(altsayi%2==0){
                System.out.println(altsayi);
            }
            altsayi++;
        }*/

        //Kullanıcı 0 girinceye kadar sayı istemeye devam eden girilen sayıları toplama ekleyen 0 girdiğinde döngüyü sonlandırıp toplamı ekrana yazan prog. do-while ile
        /*Scanner scanner = new Scanner(System.in);
        int toplam = 0;
        int girilensayi;
        do {
            System.out.println("Sayı giriniz: ");
            girilensayi = scanner.nextInt();
            toplam += girilensayi;

        } while (!(girilensayi==0));
        System.out.println("Girilen sayıların toplamı: "+toplam);*/

        //girilen aralıktaki sayıları ekrana yazdıran program while ile

       /* Scanner scanner=new Scanner(System.in);
        System.out.println("Alt sayıyı girin: ");
        int altsayi=scanner.nextInt();
        System.out.println("Üst sayıyı girin: ");
        int ustsayi=scanner.nextInt();

        while (true){
            System.out.println(altsayi);
            if (altsayi==ustsayi)
            {
                break;
            }
            else{
                altsayi++;
            }



        }*/

        //Verilen aralıktaki sayıların toplamı while ile
        /*Scanner scanner=new Scanner(System.in);
        System.out.println("Alt sayı giriniz: ");
        int altsayi=scanner.nextInt();
        System.out.println("Üst sayıyı giriniz: ");
        int ustsayi=scanner.nextInt();

        int toplam=0;

        while (true){
            if (!(altsayi==ustsayi)){
                toplam+=(altsayi+ustsayi);
                altsayi++;
            }
            else{
                break;
            }
        }
        System.out.println("Toplam sayı: "+toplam);*/


        //Girilen sayının basamağını hesaplama
        /*Scanner scanner=new Scanner(System.in);
        System.out.println("Sayı giriniz: ");
        int sayi=scanner.nextInt();
        int basamak=0;
        while(sayi>0){
            basamak++;
            sayi=sayi/10;
        }
        System.out.println("Girdiğiniz sayı "+ basamak +" basamaklıdır.");*/

        //A'dab Z'ye kadar do-while döngüsü ile ekrana yazan prog

        /*char alfabe ='A';
        do {
            System.out.println(alfabe);
            alfabe++;
        } while (alfabe <= 'Z');

        //Girilen sayıdan üst sayıya kadar olan sayıları yazdıran program

        Scanner scanner=new Scanner(System.in);
        System.out.println("İlk sayıyı giriniz: ");
        int altsayi=scanner.nextInt();*/


        //1.soru
       /*for (int i = 0; i < 5; i++) {
            for (int j = 0; j <=i ; j++) {
                System.out.print("*");
            }
            System.out.print("\n");

        }*/

        int sembol = 5;
        int bosluk = 1;
        for (int i = sembol; i > 0; i--) { // satır sayısını düzenlemek için kullandığımız for döngüsü
            for (int j = 0; j < sembol; j++) { //yıldız sayısını düzenlemek için kullandığımız for döngüsü
                System.out.print("*");
            }
            System.out.print("\n");
            for (int k = 0; k < bosluk; k++) { //boşluk sayısını düzenlemek için kullandığımız for döngüsü
                System.out.print(" ");

            }
//* ile boşluğun ters orantılı olması gerekiyor, bunların ortak noktası i değişkenli for, bu ters orantıyı bundan dolayı i for'unda oluşturmamız gerekiyordu.
            // yıldız sayısı i döndükçe azalırken bosluk sayısının artması gerekiyor.
            sembol--;
            bosluk++;

        }

        /*int deger=5;
        for (int i = 0; i < 5; i++) {
            for (int j = 0; j < deger; j++) {
                System.out.print("*");

            }
            System.out.print("\n");
            deger--;

        }*/
        //2.soru
        /*Scanner scanner=new Scanner(System.in);
        System.out.println("Sayı giriniz: ");
        int deger=scanner.nextInt();
        for (int i = 0; i <=deger ; i++) {
            for (int j = 0; j <i ; j++) {
                System.out.print("*");
            }
            System.out.print("\n");
        }*/



        /*Scanner scanner=new Scanner(System.in);
        System.out.println("Sayı giriniz: ");
        int deger=scanner.nextInt();

        for (int i = 1; i < 5; i++) {
            for (int j = i; j < 5; j++) {
                System.out.print(" ");
            }
            for (int k = 1; k <= i; k++) {
                System.out.print("*");
                System.out.print(" ");
            }
            System.out.println(" ");
        }*/


    }
}
