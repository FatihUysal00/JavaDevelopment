import java.util.ArrayList;
import java.util.Scanner;

public class Main {
    private static Sarkicilar sarkicilar = new Sarkicilar();
    private static Scanner scanner = new Scanner(System.in);

    public static void menuBastir() {
        String menu = "0. İşlemleri Görüntüle\n1. Şarkıcıları Göster\n2. Şarkıcı Ekle\n3. Şarkıcı Güncelle\n4. Şarkıcı Sil\n5. Şarkıcı Ara\n6. Uygulamadan Çık";
        System.out.println(menu);
    }
    public static void sarkiciGoster(){
        sarkicilar.sarkicilariBastir();
    }
    public static void sarkiciEkle(){
        System.out.println("Eklemek istediğiniz şarkıcı ismi giriniz: ");
        String isim = scanner.nextLine();
        sarkicilar.sarkiciEkle(isim);
    }
    public static void sarkiciGuncelle(){
        System.out.println("Güncellemek istediğiniz şarkıcının pozisyonunu giriniz:(1,2,3) ");
        int pozisyon = scanner.nextInt();
        scanner.nextLine();
        System.out.println("Şarkıcının yeni ismini giriniz: ");
        String yeni_isim = scanner.nextLine();
        sarkicilar.sarkiciGuncelle(yeni_isim, pozisyon-1);
    }
    public static void sarkiciSil(){
        System.out.println("Silmek istediğiniz şarkıcının pozisyonunu giriniz:(1,2,3) ");
        int pozisyon = scanner.nextInt();
        sarkicilar.sarkiciSil(pozisyon-1);
    }
    public static void sarkiciAra(){
        System.out.println("Aradığınız şarkıcının ismini giriniz: ");
        String isim = scanner.nextLine();
        sarkicilar.sarkiciAra(isim);
    }

    public static void main(String[] args) {
        System.out.println("Şarkıcılar Programına Hoşgeldiniz...");
        menuBastir();
        boolean cikis = false;
        while (!cikis) {
            System.out.println("İşlem seçiniz: ");
            int islem = scanner.nextInt();
            scanner.nextLine();
            switch (islem) {
                case 0:
                    menuBastir();
                    break;
                case 1:
                    sarkiciGoster();
                    break;
                case 2:
                    sarkiciEkle();
                    break;
                case 3:
                    sarkiciGuncelle();
                    break;
                case 4:
                    sarkiciSil();
                    break;
                case 5:
                    sarkiciAra();
                    break;
                case 6:
                    cikis = true;
                    System.out.println("Programdan çıkılıyor...");
                    break;
            }
        }
    }
}